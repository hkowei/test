// EECS 370 SP 23 - Lab 2
// MODIFY AND SUBMIT THIS FILE
#include "numHighBits.h"

// Takes in an integer as an argument, and returns the number of bits set high in its binary representation
int numHighBits(int input){
    //TODO: Implement this function
    return -1;
}
